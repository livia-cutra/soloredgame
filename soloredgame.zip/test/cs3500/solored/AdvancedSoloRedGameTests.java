package cs3500.solored;


import org.junit.Before;
import org.junit.Test;

import java.util.List;

import cs3500.solored.model.hw02.CardClass;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * test class for advanced solo red game extended implementation.
 */
public class AdvancedSoloRedGameTests extends AbstractSoloRedGameTests {

  private Mocks.MockAdvancedSoloRedGameModel model;

  @Before
  public void setUp() {
    model = new Mocks.MockAdvancedSoloRedGameModel();
  }

  @Test
  public void testDrawForHandWithValidCardsToDraw() {
    int initialDeckSize = model.numOfCardsInDeck();
    int expectedHandSize = 1; //1 card is drawn for a valid call

    model.drawForHand();

    assertEquals(initialDeckSize - expectedHandSize, model.numOfCardsInDeck());
    assertEquals(expectedHandSize, model.getHand().size());
  }

  @Test
  public void testDrawForHandWithNoCardsAvailable() {
    //empty the deck to test the behavior when no cards are left
    while (model.numOfCardsInDeck() > 0) {
      model.drawForHand(); //draw until the deck is empty
    }

    int initialDeckSize = model.numOfCardsInDeck();

    //attempt to draw when there are no cards left
    model.drawForHand();

    assertEquals(initialDeckSize, model.numOfCardsInDeck()); //deck size remains unchanged
    assertEquals(0, model.getHand().size()); //assuming no cards should be drawn if empty
  }

  @Test
  public void testDrawForHandWithAlreadyEmptyDeck() {
    //ensure the deck is empty
    while (model.numOfCardsInDeck() > 0) {
      model.drawForHand(); //draw until the deck is empty
    }

    model.drawForHand(); //call drawForHand again when deck is empty

    assertEquals(0, model.numOfCardsInDeck()); //deck size should still be 0
    assertEquals(0, model.getHand().size()); //no cards should be added to the hand
  }

  @Test
  public void testDrawForHand_multipleDraws() {
    //test drawing multiple times in a row
    int initialDeckSize = model.numOfCardsInDeck();
    int expectedDrawCount = 5; //draw 5 times

    for (int i = 0; i < expectedDrawCount; i++) {
      model.drawForHand();
    }

    assertEquals(initialDeckSize - expectedDrawCount, model.numOfCardsInDeck());
    assertEquals(expectedDrawCount, model.getHand().size());
  }

  @Test
  public void testDrawForHand_exceedingInitialDeckSize() {
    //test behavior when attempting to draw more cards than initially in the deck
    int initialDeckSize = model.numOfCardsInDeck();

    //draw all cards first
    while (model.numOfCardsInDeck() > 0) {
      model.drawForHand();
    }

    //try drawing one more time
    model.drawForHand();

    assertEquals(0, initialDeckSize); //deck should be empty
    assertEquals(0, model.getHand().size()); //no cards should be drawn
  }

  @Test
  public void testDrawForHand_repeatedCalls() {
    //test repeated calls to drawForHand without checking the deck size
    int initialDeckSize = model.numOfCardsInDeck();
    model.drawForHand(); //first draw

    assertEquals(initialDeckSize - 1, model.numOfCardsInDeck());
    assertEquals(1, model.getHand().size());

    //call again
    model.drawForHand();
    assertEquals(initialDeckSize - 2, model.numOfCardsInDeck());
    assertEquals(2, model.getHand().size());

    //continue until deck is empty
    while (model.numOfCardsInDeck() > 0) {
      model.drawForHand();
    }

    assertEquals(0, model.numOfCardsInDeck());
    assertEquals(initialDeckSize, model.getHand().size()); //all cards should be in hand
  }

  @Test
  public void testCardsFromModel() {
    int initialDeckSize = model.numOfCardsInDeck();
    model.drawForHand(); //draw one card

    //check that the hand size increases
    assertEquals(1, model.getHand().size());
    assertEquals(initialDeckSize - 1, model.numOfCardsInDeck());//deck size should decrease
  }

  @Test
  public void testCards() {
    List<CardClass> allCards = model.getAllCards();
    assertEquals(35, allCards.size());
  }

  @Test
  public void testIndigoBehavior() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToPalette(0, 0); //play a card to palette 0
    assertEquals(1, model.getPalette(0).size()); //expect 1 card in palette 0

  }

  @Test(expected = IllegalArgumentException.class)
  public void testStartGameWithInvalidNumericalArgs() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 1, 10); // Invalid because not enough cards
  }

  @Test
  public void testPlayingFromHandSlidesCardsDown() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 3); //shuffle, 3 palettes, hand size 3

    model.playToPalette(0, 0); //play a card from hand to palette
    assertEquals(2, model.getHand().size()); //expect hand size to be reduced by 1
    //check if the played card is in the palette
    assertTrue(model.getPalette(0).contains(deck.get(0)));
  }

  @Test
  public void testOneTurnGameLoss() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 2, 5);

    //simulate playing cards that lead to a loss
    model.playToPalette(1, 0); // Play to palette that causes a loss

    assertTrue(model.isGameOver()); //expect the game to be over
    assertFalse(model.isGameWon()); //expect the game not to be won
  }

  @Test
  public void testStartGameWithValidDeckAndValidArgs() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    assertFalse(model.isGameOver());
    assertEquals(2, model.numPalettes());
    assertEquals(5, model.getHand().size());
    assertEquals(20, model.numOfCardsInDeck());
  }

  @Test
  public void testPlayCardToCanvasContinuesGame() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    int initialHandSize = model.getHand().size();
    model.playToCanvas(0);

    assertEquals(initialHandSize - 1, model.getHand().size());
    assertNotNull(model.getCanvas());
  }

  @Test(expected = IllegalStateException.class)
  public void testCannotPlayCardToCanvasConditions() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToCanvas(0);
    model.playToCanvas(0);
  }

  @Test
  public void testOrangeBehavior() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToPalette(0, 0);
    model.playToPalette(1, 1);
    assertEquals(1, model.getPalette(0).size()); //expect 1 card in palette 0
  }

  @Test
  public void testVioletBehavior() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToPalette(0, 0);
    model.playToPalette(1, 1);
    assertEquals(1, model.getPalette(0).size()); //expect 1 card in palette 0
  }

  @Test
  public void testPlayCardsToPaletteNoDraw() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToPalette(0, 0);
    model.playToPalette(1, 1);

    assertEquals(1, model.getPalette(0).size());
    assertEquals(1, model.getPalette(1).size());
  }

  @Test
  public void testModificationOfDeckAndHands() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToCanvas(0);
    assertEquals(4, model.getHand().size());

    int modifiedDeck = model.numOfCardsInDeck();
    assertEquals(0, modifiedDeck);
  }

  @Test
  public void testBlueBehavior() {
    List<CardClass> deck = model.getAllCards();
    model.startGame(deck, true, 3, 5);

    model.playToPalette(0, 0);
    model.playToPalette(1, 1);
    assertEquals(1, model.getPalette(0).size()); //expect 1 card in palette 0
  }

}


