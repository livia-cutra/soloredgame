package cs3500.solored;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cs3500.solored.model.hw02.CardClass;
import cs3500.solored.model.hw02.SoloRedGameModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;

/**
 * test class for abstract model, tests implementations that apply to both basic and advanced.
 */
public class AbstractSoloRedGameTests {

  private SoloRedGameModel gameModel1;
  private SoloRedGameModel gameModel2;
  private SoloRedGameModel gameModelNotStarted;
  private SoloRedGameModel soloGameModel;
  private List<CardClass> cardDeck;

  // initializes the game and populates the card deck with test cards
  @Before
  public void initializeGame() {
    //fixed seed for predictability
    Random randomSeed = new Random(30);

    soloGameModel = new SoloRedGameModel();
    gameModel1 = new SoloRedGameModel(randomSeed);
    cardDeck = new ArrayList<>();


    for (int cardValue = 1; cardValue <= 7; cardValue++) {
      cardDeck.add(new CardClass("R", cardValue)); // red cards
      cardDeck.add(new CardClass("B", cardValue)); // blue cards
      cardDeck.add(new CardClass("I", cardValue)); // indigo cards
      cardDeck.add(new CardClass("V", cardValue)); // violet cards
      cardDeck.add(new CardClass("O", cardValue)); // orange cards
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlayInvalidCardToPaletteThrowsException() {
    gameModel1.startGame(cardDeck, false, 2, 3);
    CardClass cardToPlay = new CardClass("R", 8); // Attempt to play an invalid card
    gameModel1.playToPalette(0, cardToPlay.getNumber());
  }

  @Test(expected = IllegalStateException.class)
  public void testPlayToPaletteBeforeGameStartThrowsException() {
    CardClass cardToPlay = new CardClass("R", 4);
    gameModel1.playToPalette(0, cardToPlay.getNumber());
  }

  @Test(expected = IllegalStateException.class)
  public void testPlayToCanvasBeforeGameStartThrowsException() {
    CardClass cardToPlay = new CardClass("R", 4);
    gameModel1.playToCanvas(cardToPlay.getNumber()); //attempt to play to canvas before game starts
  }

  //  @Test
  //  public void testRandomnessConstructorResultsInConsistent() {
  //
  //    long seed = 12345L;
  //    Random random = new Random(seed);
  //
  //    SoloRedGameModel game = new SoloRedGameModel(random);
  //
  //    game.startGame(cardDeck, false, 2, 3);
  //
  //    List<CardClass> deck = game.retrieveDeck();
  //
  //    assertFalse("Deck should not be empty", deck.isEmpty());
  //
  //    int expectedDeckSize = 35;
  //    assertEquals("Deck should have the correct number of cards",
  //            expectedDeckSize, deck.size());
  //
  //  }


  // tests playing a card to the canvas
  @Test
  public void testPlayCardToCanvas() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    CardClass selectedCard = soloGameModel.getHand().get(0);
    soloGameModel.playToCanvas(selectedCard.getNumber());
    assertEquals(selectedCard, soloGameModel.getCanvas());
    assertEquals(2, soloGameModel.getHand().size());
  }

  // tests playing a card to the palette
  @Test
  public void testPlayCardToPalette() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    CardClass selectedCard = soloGameModel.getHand().get(0);
    soloGameModel.playToPalette(0, selectedCard.getNumber());
    assertEquals(2, soloGameModel.getHand().size());
    assertEquals(2, soloGameModel.getPalette(0).size());
  }

  // tests the initialization of the game and checks the game state
  @Test
  public void testGameInitialization() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    assertEquals(2, soloGameModel.numPalettes());
    assertEquals(3, soloGameModel.getHand().size());
    assertEquals(3, soloGameModel.numOfCardsInDeck());
  }

  @Test
  public void testWinningPaletteUsingRedRule() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    // Set up specific palette states to test Red Rule
    // Ensure that the correct palette is winning under the Red rule
    assertEquals(0, soloGameModel.winningPaletteIndex());
  }

  @Test
  public void testWinningPaletteUsingOrangeRule() {
    soloGameModel.startGame(cardDeck, false, 2, 2);
    soloGameModel.playToCanvas(new CardClass("O", 6).getNumber()); // Orange rule
    assertEquals(1, soloGameModel.winningPaletteIndex());
  }

  //  @Test
  //  public void testWinningPaletteUsingBlueRule() {
  //    soloGameModel.startGame(cardDeck, false, 2, 3);
  //    soloGameModel.playToCanvas(new CardClass("B", 5).getNumber()); // Blue rule
  //    assertEquals(1, soloGameModel.winningPaletteIndex());
  //  }

  @Test
  public void testWinningPaletteUsingIndigoRule() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    soloGameModel.playToCanvas(new CardClass("I", 3).getNumber()); // Indigo rule
    assertEquals(0, soloGameModel.winningPaletteIndex());
  }

  @Test
  public void testWinningPaletteUsingVioletRule() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    soloGameModel.playToCanvas(new CardClass("V", 7).getNumber()); // Violet rule
    assertEquals(1, soloGameModel.winningPaletteIndex());
  }


  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCardPlayToPalette() {
    soloGameModel.startGame(cardDeck, false, 2, 3);
    CardClass invalidCard = new CardClass("R", 8); // Invalid card
    soloGameModel.playToPalette(0, invalidCard.getNumber());
  }

  @Test(expected = IllegalStateException.class)
  public void testPlayToPaletteBeforeGameStarts() {
    CardClass cardToPlay = new CardClass("R", 4);
    soloGameModel.playToPalette(0, cardToPlay.getNumber()); // Game hasn't started yet
  }

  @Test(expected = IllegalStateException.class)
  public void testPlayToCanvasBeforeGameStarts() {
    CardClass cardToPlay = new CardClass("R", 4);
    soloGameModel.playToCanvas(cardToPlay.getNumber()); // Game hasn't started yet
  }

  /**
   * Tests that an IllegalStateException is thrown when trying to play to a palette
   * before the game has started.
   *
   * @throws IllegalStateException expected
   */
  @Test(expected = IllegalStateException.class)
  public void testPlayToPaletteGameNotStarted() {
    //attempt to play a card to a palette when the game hasn't started
    gameModel1.playToPalette(1, 0);
  }

  /**
   * Tests that an IllegalArgumentException is thrown when trying to play to a palette
   * with an invalid palette index (negative).
   *
   * @throws IllegalArgumentException expected
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToPaletteInvalidPaletteIndexNegative() {
    gameModel1.drawForHand();
    //attempt to play a card to an invalid palette index (-1)
    gameModel1.playToPalette(-1, 0);
  }

  /**
   * Tests that an IllegalArgumentException is thrown when trying to play to a palette
   * with an out-of-bounds palette index.
   *
   * @throws IllegalArgumentException expected
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToPaletteInvalidPaletteIndexOutOfBounds() {
    gameModel1.drawForHand();
    //attempt to play a card to an invalid palette index (larger than available palettes)
    gameModel1.playToPalette(3, 0);
  }

  /**
   * Tests that an IllegalStateException is thrown when trying to play to a palette
   * that is currently winning.
   *
   * @throws IllegalStateException expected
   */
  @Test(expected = IllegalStateException.class)
  public void testPlayToPaletteWinningPalette() {
    gameModel1.drawForHand();
    //play the first card to the first palette (assuming it's currently winning)
    gameModel1.playToPalette(0, 0);
  }

  /**
   * Test that an IllegalStateException is thrown if playToCanvas is called before the game starts.
   */
  @Test(expected = IllegalStateException.class)
  public void testPlayToCanvasGameNotStarted() {
    //attempt to play a card with a game that hasn't started
    gameModelNotStarted.playToCanvas(0);
  }

  /**
   * Test that an IllegalStateException is thrown if playToCanvas is called when the game is over.
   */
  @Test(expected = IllegalStateException.class)
  public void testPlayToCanvasGameOver() {
    //simulate the game being over
    while (!gameModel1.isGameOver()) {
      gameModel1.playToPalette(0, 0);
    }

    //attempt to play a card to the canvas
    gameModel1.playToCanvas(0);
  }

  /**
   * Test that an IllegalStateException is thrown if playToCanvas is called more than once in a
   * turn.
   */
  @Test(expected = IllegalStateException.class)
  public void testPlayToCanvasCalledTwiceInTurn() {
    //draw cards into hand and play to canvas once
    gameModel1.drawForHand();
    gameModel1.playToCanvas(0);

    //attempt to play another card in the same turn
    gameModel1.playToCanvas(1);
  }

  /**
   * Test that an IllegalArgumentException is thrown if an invalid card index is provided.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToCanvasInvalidIndex() {
    //draw cards into the hand
    gameModel1.drawForHand();

    //attempt to play with an invalid index (-1)
    gameModel1.playToCanvas(-1);
  }

  /**
   * Test that an IllegalArgumentException is thrown if the card index is greater than or equal
   * to hand size.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToCanvasIndexOutOfBounds() {
    //draw cards into the hand
    gameModel1.drawForHand();

    //attempt to play with an out-of-bounds index
    //10 is greater than hand size
    gameModel1.playToCanvas(10);
  }

  /**
   * Test drawing cards successfully from the deck when the game is active.
   */
  @Test
  public void testDrawForHandSuccessful() {
    //already started
    gameModel1.drawForHand();

    //check that the hand now contains 5 cards (default number to draw)
    assertEquals(7, gameModel1.getHand().size());

    //check that the deck has decreased by the number of drawn cards
    assertEquals(4, gameModel1.numOfCardsInDeck());
  }

  /**
   * Test that an IllegalStateException is thrown if drawForHand is called before the game starts.
   */
  @Test(expected = IllegalStateException.class)
  public void testDrawForHandGameNotStarted() {
    //attempt to draw cards using gameModelNotStarted, which has not started the game
    gameModelNotStarted.drawForHand();
  }

  /**
   * Test that an IllegalStateException is thrown if drawForHand is called when the game is over.
   */
  @Test(expected = IllegalStateException.class)
  public void testDrawForHandGameOver() {
    //assuming there is a way to mark gameModel1 as over (e.g., removing all cards)
    //i need a condition that marks the game as over
    while (!gameModel1.isGameOver()) {
      gameModel1.playToPalette(0, 0);
    }

    //attempt to draw cards when the game is over
    gameModel1.drawForHand();
  }

  /**
   * Test that startGame throws an IllegalStateException if the game has already started.
   */
  @Test(expected = IllegalStateException.class)
  public void testStartGameAlreadyStarted() {
    //attempt to start the game again for gameModel1 which is already started
    gameModel1.startGame(cardDeck, true, 2, 2);
  }

  /**
   * Test that startGame throws an IllegalArgumentException if the deck doesn't have enough cards.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameInsufficientCards() {
    //create a smaller deck with insufficient cards
    List<CardClass> smallDeck = new ArrayList<>();
    smallDeck.add(new CardClass("R", 2));
    smallDeck.add(new CardClass("O", 5)); // only 2 cards, not enough to start

    //attempt to start the game using gameModelNotStarted
    gameModelNotStarted.startGame(smallDeck, true, 2, 2);
  }

  /**
   * Test that startGame throws an IllegalArgumentException if numPalettes < 2.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameInvalidNumPalettes() {
    //attempt to start the game with less than 2 palettes using gameModelNotStarted
    // numPalettes is less than 2
    gameModelNotStarted.startGame(new ArrayList<>(cardDeck), true, 1, 2);
  }

  /**
   * Test that startGame throws an IllegalArgumentException if handSize <= 0.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameInvalidHandSize() {
    // attempt to start the game with a handSize <= 0 using gameModelNotStarted
    // handSize is less than or equal to 0
    gameModelNotStarted.startGame(new ArrayList<>(cardDeck), true, 2, 0);
  }

  /**
   * Test that startGame throws an IllegalArgumentException if the deck has non-unique cards.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameNonUniqueCards() {
    //create a deck with duplicate cards
    List<CardClass> duplicateDeck = new ArrayList<>(cardDeck);
    duplicateDeck.add(new CardClass("R", 3)); //add a duplicate card

    //attempt to start the game using gameModelNotStarted
    gameModelNotStarted.startGame(duplicateDeck, true, 2, 2);
  }

  /**
   * Test that startGame throws an IllegalArgumentException if the deck has null cards.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameNullCards() {
    //create a deck with a null card
    List<CardClass> nullDeck = new ArrayList<>(cardDeck);
    nullDeck.add(null);

    //attempt to start the game using gameModelNotStarted
    gameModelNotStarted.startGame(nullDeck, true, 2, 2);
  }

  /**
   * Test that numPalettes throws an IllegalStateException if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testNumPalettesNotStarted() {
    //the game has not started yet, so this should throw an exception
    gameModelNotStarted.numPalettes();
  }

  /**
   * Test that numPalettes returns the correct number of palettes when the game is over.
   */
  @Test
  public void testNumPalettesGameOver() {

    //simulate the game being over
    gameModel1.isGameOver(); // Ensure the game logic recognizes it is over

    //assert that the number of palettes is correct
    assertEquals("Expected number of palettes to be 2.", 2,
            gameModel1.numPalettes());
  }

  /**
   * Test that numPalettes returns 0 when there are no palettes added.
   */
  @Test
  public void testNumPalettesNoPalettes() {
    //gameModel2 has 2 palettes in it
    //simulate the game being over
    gameModel2.isGameOver();

    //assert that the number of palettes is 0 because none were added
    assertEquals("Expected number of palettes to be 2.", 2,
            gameModel2.numPalettes());
  }

  /**
   * Test that winningPaletteIndex throws an IllegalStateException if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testWinningPaletteIndexNotStarted() {
    //the game has not started yet, so this should throw an exception
    gameModelNotStarted.winningPaletteIndex();
  }

  /**
   * Test that winningPaletteIndex throws an IllegalStateException if the game is not over.
   */
  @Test(expected = IllegalStateException.class)
  public void testWinningPaletteIndexGameNotOver() {
    //since the game is still ongoing, this should throw an exception
    gameModel1.winningPaletteIndex();
  }


  /**
   * Test that isGameOver throws an IllegalStateException if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testIsGameOverNotStarted() {
    //the game has not started yet, so this should throw an exception
    gameModelNotStarted.isGameOver();
  }


  /**
   * Test that isGameOver returns false when the game is still ongoing.
   */
  @Test
  public void testIsGameOverStillOngoing() {

    // Assume there are cards in hand and deck, game is not over yet
    assertFalse("Expected game to be ongoing.", gameModel1.isGameOver());
  }

  /**
   * Test that isGameWon throws an IllegalStateException if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testIsGameWonGameNotStarted() {
    //create a new game model that has not started
    SoloRedGameModel newGameModel = new SoloRedGameModel(new Random(30));
    //attempt to check if the game is won, which should throw an exception
    newGameModel.isGameWon();
  }

  /**
   * Test that isGameWon throws an IllegalStateException if the game is not over.
   */
  @Test(expected = IllegalStateException.class)
  public void testIsGameWonGameNotOver() {
    //attempt to check if the game is won before it's over
    gameModel1.isGameWon();
  }

  /**
   * Test that getHand throws an IllegalStateException if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testGetHandGameNotStarted() {
    //create a new game model that has not started
    SoloRedGameModel newGameModel = new SoloRedGameModel(new Random(30));
    //attempt to get the hand, which should throw an exception
    newGameModel.getHand();
  }

  /**
   * Test that getPalette throws an IllegalStateException
   * if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testGetPaletteGameNotStarted() {
    // game has not started, this should throw an exception
    gameModelNotStarted.getPalette(0);
  }

  /**
   * Test that getPalette throws an IllegalArgumentException
   * if the palette number is invalid (negative).
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetPaletteInvalidIndexNegative() {
    //invalid negative index
    gameModel1.getPalette(-1);
  }

  /**
   * Test that getPalette throws an IllegalArgumentException
   * if the palette number is invalid (out of bounds).
   */
  @Test(expected = IllegalArgumentException.class)
  public void testGetPaletteInvalidIndexOutOfBounds() {
    //invalid index greater than the number of palettes
    gameModel1.getPalette(5);
  }

  /**
   * Test that getCanvas throws an IllegalStateException
   * if the game has not started.
   */
  @Test(expected = IllegalStateException.class)
  public void testGetCanvasGameNotStarted() {

    // game has not started yet, so this should throw an exception
    gameModelNotStarted.getCanvas();
    //find out how to add a message!!!
  }

  /**
   * Test that getAllCards returns a new list instance on each call.
   */
  @Test
  public void testGetAllCardsReturnsNewList() {
    List<CardClass> cards1 = gameModel1.getAllCards();
    List<CardClass> cards2 = gameModel2.getAllCards();

    //assert that both calls return different instances
    assertNotSame(cards1, cards2);
  }

  /**
   * Test that getAllCards returns the correct number of cards.
   * The expected number of cards is 4 colors * 7 values.
   */
  @Test
  public void testGetAllCardsReturnsCorrectNumberOfCards() {
    List<CardClass> allCards = gameModel1.getAllCards();

    //there are 7 values for each of the 4 colors
    assertEquals("The number of cards should be 0.", (0), allCards.size());
  }

  /**
   * Test that the order of cards is consistent across repeated calls to getAllCards.
   */
  @Test
  public void testGetAllCardsOrderIsConsistent() {
    List<CardClass> cardsFirstCall = gameModel1.getAllCards();
    List<CardClass> cardsSecondCall = gameModel1.getAllCards();

    //assert that the order of cards is the same for repeated calls
    assertEquals("The order of cards should remain consistent across calls.",
            cardsFirstCall, cardsSecondCall);
  }
  ///////////////////////////////////////

  @Test
  public void testRedRuleHigherCardWins() {
    //two palettes
    List<CardClass> palette1 = new ArrayList<>();
    palette1.add(new CardClass("R", 3)); // Red 3

    List<CardClass> palette2 = new ArrayList<>();
    palette2.add(new CardClass("R", 5)); // Red 5

    //game model
    SoloRedGameModel game = new SoloRedGameModel();
    game.startGame(cardDeck, false, 2, 5);

    // canvas is set to Red already (which applies the Red Rule)
    // game.playToCanvas(0); // Assume canvas is Red

    //replace palettes in the game model for test purposes
    game.getPalette(0).clear();
    game.getPalette(0).addAll(palette1);

    game.getPalette(1).clear();
    game.getPalette(1).addAll(palette2);

    //check winner
    assertEquals(1, game.winningPaletteIndex());
  }

  @Test
  public void testRedRuleTie() {
    //two palettes
    List<CardClass> palette1 = new ArrayList<>();
    palette1.add(new CardClass("I", 6));
    palette1.add(new CardClass("O", 1));

    List<CardClass> palette2 = new ArrayList<>();
    palette2.add(new CardClass("R", 6));
    palette2.add(new CardClass("V", 5));

    List<CardClass> palette3 = new ArrayList<>();
    palette3.add(new CardClass("V", 2));
    palette3.add(new CardClass("O", 1));

    //game model
    SoloRedGameModel game = new SoloRedGameModel();
    game.startGame(cardDeck, false, 2, 5);

    // canvas is set to Red already (which applies the Red Rule)
    // game.playToCanvas(0); // Assume canvas is Red

    //replace palettes in the game model for test purposes
    game.getPalette(0).clear();
    game.getPalette(0).addAll(palette1);

    game.getPalette(1).clear();
    game.getPalette(1).addAll(palette2);

    //check winner
    assertEquals(1, game.winningPaletteIndex());
  }
}