package cs3500.solored;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.CardClass;
import cs3500.solored.model.hw02.SoloRedGameModel;
import cs3500.solored.model.hw04.AdvancedSoloRedGameModel;

/**
 * class that represents a mock card.
 */
public abstract class Mocks implements Card {

  /**
   * mock implementation of the SoloRedGameModel class for testing purposes.
   */
  public static class MockSoloRedGameModel1 extends SoloRedGameModel {

    //    boolean isGameOver = false;

    public boolean gameStarted = true;
    public List<CardClass> passedDeck;
    public boolean passedShuffle;
    public int passedNumPalettes;
    public int passedHandSize;

    @Override
    public void startGame(List<CardClass> deck, boolean shuffle, int numPalettes, int handSize) {
      // Print the values passed to startGame
      System.out.println("startGame called with parameters:");
      System.out.println("Deck: " + deck);
      System.out.println("Shuffle: " + shuffle);
      System.out.println("Num Palettes: " + numPalettes);
      System.out.println("Hand Size: " + handSize);

      //capture the inputs when the method is called
      this.passedDeck = deck;
      this.passedShuffle = shuffle;
      this.passedNumPalettes = numPalettes;
      this.passedHandSize = handSize;
      gameStarted = true;
      //print to confirm the game has started
      System.out.println("Game started: " + gameStarted);
    }
  }

  //more to create after fixing playGame() issue

  /**
   * mock appendable that simulates a failure by throwing an IOException.
   */
  public static class FailingAppendable implements Appendable {

    @Override
    public Appendable append(CharSequence csq) throws IOException {
      throw new IOException("Simulated Appendable failure");
    }

    @Override
    public Appendable append(CharSequence csq, int start, int end) throws IOException {
      throw new IOException("Simulated Appendable failure");
    }

    @Override
    public Appendable append(char c) throws IOException {
      throw new IOException("Simulated Appendable failure");
    }
  }

  /**
   * mock appendable that simulates a playToCanvas exception.
   */
  public static class MockSoloRedGameModelWithCanvasException extends SoloRedGameModel {
    @Override
    public void playToCanvas(int cardIdxInHand) throws IllegalArgumentException {
      //simulate an exception when attempting to play to the canvas
      throw new IllegalArgumentException("Invalid move! Cannot play to the canvas.");
    }
  }

  /**
   * mock appendable that simulates a legal move.
   */
  public static class MockSoloRedGameModelCanvasPlayed extends SoloRedGameModel {
    public boolean canvasPlayed = false; //track if a card was successfully played to the canvas

    @Override
    public void playToCanvas(int cardIdxInHand) {
      //simulate a valid move where a card is played to the canvas
      canvasPlayed = true; //log that the move was made
    }
  }

  /**
   * mock appendable that simulates if a palette was played.
   */
  public static class MockSoloRedGameModelPlayToPalette extends SoloRedGameModel {
    boolean palettePlayed = false; //tracks whether a card is played to the palette

    @Override
    public void playToPalette(int playerIndex, int cardIndex) {
      //an attempt to play to the palette was made
      palettePlayed = true;
    }
  }

  /**
   * mock appendable that simulates which card was played to which palette.
   */
  public static class MockSoloRedGameModelPlayToPaletteIndex extends SoloRedGameModel {
    int loggedPlayerIndex = -1;
    int loggedCardIndex = -1;

    @Override
    public void playToPalette(int playerIndex, int cardIndex) {
      this.loggedPlayerIndex = playerIndex;
      this.loggedCardIndex = cardIndex;
    }
  }

  /**
   * mock appendable that simulates start game exception.
   */
  public static class MockSoloRedGameModelGameException extends SoloRedGameModel {
    @Override
    public void startGame(List<CardClass> deck, boolean shuffle, int numPalettes, int handSize) {
      throw new IllegalArgumentException("Invalid game parameters"); //simulate an exception
    }
  }

  /**
   * mock appendable that simulates if game started.
   */
  public static class MockSoloRedGameModelStartGame extends SoloRedGameModel {
    boolean gameStarted = false;

    @Override
    public void startGame(List<CardClass> deck, boolean shuffle, int numPalettes, int handSize) {
      gameStarted = true; // log that the game has started
    }
  }

  /**
   * mock appendable that simulates if game started and palette was called.
   */
  public static class MockSoloRedGameModelPaletteAndGame extends SoloRedGameModel {
    boolean gameStarted = false;
    boolean playToPaletteCalled = false;

    @Override
    public void startGame(List<CardClass> deck, boolean shuffle, int numPalettes, int handSize) {
      gameStarted = true; // Mark the game as started
    }

    @Override
    public void playToPalette(int playerIndex, int cardIndex) throws IllegalArgumentException {
      playToPaletteCalled = true;
      throw new IllegalArgumentException("Invalid play to palette");
    }
  }

  /**
   * mock appendable that simulates a game ending naturally.
   */
  public static class MockSoloRedGameModelGameEndsNaturally extends SoloRedGameModel {
    boolean gameStarted = false;
    boolean playToPaletteCalled = false;
    boolean isGameOver = false;

    @Override
    public void startGame(List<CardClass> deck, boolean shuffle, int numPalettes, int handSize) {
      gameStarted = true; //log game started
    }

    @Override
    public boolean isGameOver() {
      return isGameOver;
    }

    @Override
    public void playToPalette(int playerIndex, int cardIndex) {
      playToPaletteCalled = true; //log play to palette was called
      isGameOver = true;
    }
  }

  /**
   * mock appendable that simulates a card being played ot palette.
   */
  public static class MockSoloRedGameModelPlayToPalette1 extends SoloRedGameModel {
    List<Integer> palettePlayed = new ArrayList<>(); //track played cards

    @Override
    public void playToPalette(int cardIndex, int paletteIdx) {
      // Log the card index played to the palette
      palettePlayed.add(cardIndex);
    }


  }

  /**
   * New mock model for SoloRedGameModel, used for testing different game states and player actions.
   */
  public static class MockSoloRedGameModel extends SoloRedGameModel {
    private List<CardClass> deck;
    private List<CardClass> hand;
    private int cardsDrawn = 0;

    public MockSoloRedGameModel(List<CardClass> deck, List<CardClass> hand) {
      this.deck = deck;
      this.hand = hand;
    }

    @Override
    public List<CardClass> getHand() {
      return this.hand;
    }

    @Override
    public void playToPalette(int playerIndex, int cardIndex) {
      //simulate playing a card to the palette
      this.hand.remove(cardIndex);  //assume card is removed from hand
      cardsDrawn++;  //simulate drawing one card after playing
    }

    @Override
    public void playToCanvas(int cardIdxInHand) {
      // Simulate playing a card to the canvas
      this.hand.remove(cardIdxInHand); //assume card is removed from hand
      cardsDrawn += Math.min(2, deck.size());//simulate drawing additional cards if deck has enough
    }

    @Override
    public void drawForHand() {
      for (int i = 0; i < cardsDrawn; i++) {
        hand.add(deck.remove(0));
      }
    }

    public int getCardsDrawn() {
      return cardsDrawn;
    }
  }

  /**
   * a mock class used to test advancedsoloredgame model.
   */
  public static class MockAdvancedSoloRedGameModel extends AdvancedSoloRedGameModel {

    public MockAdvancedSoloRedGameModel() {
      super();
    }

    public int numOfCardsInDeck() {
      return super.numOfCardsInDeck();
    }

    public List<CardClass> getHand() {
      return super.getHand();
    }


  }

}
