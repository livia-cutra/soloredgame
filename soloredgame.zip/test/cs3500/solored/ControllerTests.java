package cs3500.solored;


import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.List;

import cs3500.solored.controller.RedGameController;
import cs3500.solored.controller.SoloRedTextController;
import cs3500.solored.model.hw02.CardClass;
import cs3500.solored.model.hw02.SoloRedGameModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * unit tests for the controllers.
 */
public class ControllerTests {

  @Test
  public void testMockModelInvalidControllerInput() {
    System.out.println("Test started.");
    //simulate invalid input: "invalid move\nanother invalid input\n"
    Readable input = new StringReader("invalid move\nanother invalid input\n");
    Appendable output = new StringBuilder();

    //random seed
    //Random rand = new Random(30);

    //create the mock model
    Mocks.MockSoloRedGameModel1 mockModel = new Mocks.MockSoloRedGameModel1();

    //create the controller with the input and output
    RedGameController controller = new SoloRedTextController(input, output);

    System.out.println("Before calling playGame.");
    //play a small game
    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3),
                    new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    // After the game starts
    System.out.println("After calling playGame.");
    System.out.println("Game Started: " + mockModel.gameStarted);

    //verify that invalid inputs were handled correctly in the output
    String outputString = output.toString();
    System.out.println("Output: " + outputString);

    //check that the output contains the expected error message for invalid input
    assertTrue("Expected invalid input message was not found.",
            outputString.contains("Invalid move, try again: "));

    //verify the game started correctly, even if invalid inputs were provided
    assertTrue("Game should have started despite invalid inputs.", mockModel.gameStarted);

  }

  // keeps giving "game has not started" IAE
  //testConfirmInputsToStartGameModelMethods
  @Test
  public void testStartGameInputs() {
    // setup
    List<CardClass> expectedDeck = Arrays.asList(
            new CardClass("R", 4),
            new CardClass("B", 1),
            new CardClass("I", 3),
            new CardClass("V", 3),
            new CardClass("R", 6), new CardClass("B", 5),
            new CardClass("I", 2), new CardClass("V", 7));
    boolean expectedShuffle = false;
    int expectedNumPalettes = 2;
    int expectedHandSize = 2;

    //mock model
    Mocks.MockSoloRedGameModel1 mockModel = new Mocks.MockSoloRedGameModel1();

    //controller
    RedGameController controller = new SoloRedTextController(new StringReader(""),
            new StringBuilder());

    //play game with expected inputs
    controller.playGame(mockModel, expectedDeck, expectedShuffle, expectedNumPalettes,
            expectedHandSize);

    //verify that correct inputs were passed to the model's startGame method
    assertEquals("Deck was not passed correctly to startGame method",
            expectedDeck, mockModel.passedDeck);
    assertEquals("Shuffle flag was not passed correctly to startGame method",
            expectedShuffle, mockModel.passedShuffle);
    assertEquals("Number of palettes was not passed correctly to startGame method",
            expectedNumPalettes, mockModel.passedNumPalettes);
    assertEquals("Hand size was not passed correctly to startGame method",
            expectedHandSize, mockModel.passedHandSize);
  }

  @Test
  public void testExpectedFirstStateOfGame() {
    //define the expected initial state of the game
    boolean expectedGameStarted = false;

    //create a mock model
    Mocks.MockSoloRedGameModel1 mockModel = new Mocks.MockSoloRedGameModel1();
    mockModel.gameStarted = expectedGameStarted;

    //verify the initial state of the game
    assertFalse("Game should not be started initially.", mockModel.gameStarted);
  }

  @Test
  public void testAppendableFailureBehavior() {
    //mock Readable input and the failing appendable output
    Readable input = new StringReader("valid input\n");
    Appendable failingOutput = new Mocks.FailingAppendable();

    //real model
    SoloRedGameModel gameModel = new SoloRedGameModel();

    //controller
    RedGameController controller = new SoloRedTextController(input, failingOutput);

    try {
      //attempt to start the game with valid parameters
      controller.playGame(gameModel, Arrays.asList(
                      new CardClass("R", 4), new CardClass("B", 1),
                      new CardClass("I", 3), new CardClass("V", 3),
                      new CardClass("R", 6), new CardClass("B", 5),
                      new CardClass("I", 2), new CardClass("V", 7)),
              false, 2, 2);

      //if no exception is thrown, the test should fail
      fail("Expected an IOException to be thrown due to failing Appendable.");

    } catch (IllegalStateException e) {
      //check that the controller handled the IOException and wrapped in an IllegalStateException
      assertTrue("Expected the message to contain 'Unable to transmit output.'.",
              e.getMessage().contains("Unable to transmit output."));
    }
  }


  @Test(expected = IllegalArgumentException.class)
  public void testPlayGameWithNullModel() {
    //set up valid input and output, but null for the game model
    Readable input = new StringReader("valid input\n");
    Appendable output = new StringBuilder();

    RedGameController controller = new SoloRedTextController(input, output);

    //attempt to start the game with a null game model
    controller.playGame(null, Arrays.asList(new CardClass("R", 4),
            new CardClass("B", 1), new CardClass("R", 6),
            new CardClass("B", 5),
            new CardClass("I", 2),
            new CardClass("V", 7)), false, 2, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlayGameWithNullDeck() {
    //set up valid input, output, and game model, but null for the deck
    Readable input = new StringReader("valid input\n");
    Appendable output = new StringBuilder();
    SoloRedGameModel model = new SoloRedGameModel();

    RedGameController controller = new SoloRedTextController(input, output);

    //attempt to start the game with a null deck
    controller.playGame(model, null, false, 2, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlayGameWithNullInput() {
    //set up null input, but valid output and game model
    Appendable output = new StringBuilder();
    SoloRedGameModel model = new SoloRedGameModel();

    RedGameController controller = new SoloRedTextController(null, output);

    //attempt to start the game with a null input
    controller.playGame(model, Arrays.asList(new CardClass("R", 4),
            new CardClass("B", 1)), false, 2, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlayGameWithNullOutput() {
    //set up valid input and game model, but null output
    Readable input = new StringReader("valid input\n");
    SoloRedGameModel model = new SoloRedGameModel();

    RedGameController controller = new SoloRedTextController(input, null);

    //attempt to start the game with a null output
    controller.playGame(model, Arrays.asList(new CardClass("R", 4),
            new CardClass("B", 1)), false, 2, 2);
  }

  @Test
  public void testQuittingMidCommand() {
    //simulate input where the player starts a move and then quits mid-command
    Readable input = new StringReader("invalid move\nq\n");
    Appendable output = new StringBuilder();

    SoloRedGameModel model = new SoloRedGameModel();
    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(model, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3),
                    new CardClass("V", 2),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    //check if the output contains the quitting message
    assertTrue("Expected quit message was not found.",
            outputString.contains("Game quit!\n"
                    +
                    "State of game when quit:\n"
                    +
                    "Palettes: " + "P1 \n" + "P2 \n"
                    +
                    "Canvas: " + "R1" + "\n"
                    +
                    "Cards left in deck: " + 4 + "\n"
                    +
                    "Number of cards in deck: " + 4 + "\n"));

    //verify the game status to confirm that it ended correctly
    assertTrue("Expected the game to be over after quitting.", model.isGameOver());
  }

  //  @Test
  //  public void testGameQuit() {
  //    Readable input = new StringReader("q\n");
  //    Appendable output = new StringBuilder();
  //
  //    SoloRedGameModel model = new SoloRedGameModel();
  //    RedGameController controller = new SoloRedTextController(input, output);
  //
  //    controller.playGame(model, Arrays.asList(new CardClass("R", 4),
  //                    new CardClass("B", 1),
  //                    new CardClass("I", 3),
  //                    new CardClass("V", 2),
  //                    new CardClass("R", 6),
  //                    new CardClass("B", 5),
  //                    new CardClass("I", 2),
  //                    new CardClass("V", 7)),
  //            false, 2, 2);
  //
  //    String outputString = output.toString();
  //
  //    //check if the output contains the quitting message
  //    assertTrue("Expected quit message was not found.",
  //            outputString.contains("Game quit!\n"
  //                    +
  //                    "State of game when quit:\n"
  //                    +
  //                    "Palettes: " + "P1 \n" + "P2 \n"
  //                    +
  //                    "Canvas: " + "R1" + "\n"
  //                    +
  //                    "Cards left in deck: " + 4 + "\n"
  //                    +
  //                    "Number of cards in deck: " + 4 + "\n"));
  //
  //    assertTrue("Expected the game to be over after quitting.", model.isGameOver());
  //    }


  @Test
  public void testPlayToCanvasExceptionsDoNotHaltProgram() {
    //player tries to make a move, but an exception will be thrown
    Readable input = new StringReader("1 1\nq\n");
    Appendable output = new StringBuilder();

    //create mock model that will throw an exception when trying to play to canvas
    Mocks.MockSoloRedGameModelWithCanvasException mockModel =
            new Mocks.MockSoloRedGameModelWithCanvasException();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 2),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    // verify that the game output contains the exception message and proceeds to allow quitting
    String outputString = output.toString();

    // check if the output contains the expected error message from the exception
    assertTrue("Expected error message was not found in output.",
            outputString.contains("Invalid move! Cannot play to the canvas."));

    // check that the game still allows quitting after the error
    assertTrue("Expected quit message was not found after handling the exception.",
            outputString.contains("Game quit! \n"));
  }

  @Test
  public void testPlayToCanvasWithLegalModelInput() {
    //"1 1" represents a valid play command
    Readable input = new StringReader("1 1\nq\n");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelCanvasPlayed mockModel =
            new Mocks.MockSoloRedGameModelCanvasPlayed();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 2),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    //verify legal move was made
    assertTrue("The game model did not log the move to the canvas.",
            mockModel.canvasPlayed);

    String outputString = output.toString();

    //check if the output shows game quit successfully
    assertTrue("Expected quit message was not found in the output.",
            outputString.contains("Game quit!\n"));
  }

  @Test
  public void testPlayToCanvasWithInvalidInput() {
    //simulate invalid input (letters instead of numbers)
    Readable input = new StringReader("a b\n");  // invalid input (letters instead of numbers)
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelCanvasPlayed mockModel = new Mocks.MockSoloRedGameModelCanvasPlayed();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1), new CardClass("I", 3),
                    new CardClass("V", 3), new CardClass("R", 6),
                    new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    //nothing should have been played to the canvas due to invalid input
    assertFalse(mockModel.canvasPlayed);  // invalid input so canvasPlayed should still be false

    //simulate valid input (numbers instead of letters)
    input = new StringReader("1 1\n");

    //replay game with valid input
    controller.playGame(mockModel, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3),
                    new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    //canvasPlayed is now true because the valid move has been made
    assertTrue(mockModel.canvasPlayed);  //valid input so canvasPlayed should now be true

    //simulate quit
    input = new StringReader("q\n");

    //replay game with quit input
    controller.playGame(mockModel, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3),
                    new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    //check if the output shows game quit successfully
    assertTrue("Expected quit message was not found in the output.",
            outputString.contains("Game quit!\n"));

  }

  @Test
  public void testPlayToPaletteWithNegativeNumberInput() {
    //simulate invalid input (-1 is the negative number)
    Readable input = new StringReader("-1 1\n");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelPlayToPalette mockModel =
            new Mocks.MockSoloRedGameModelPlayToPalette();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(new CardClass("R", 4),
                    new CardClass("B", 1),
                    new CardClass("I", 3),
                    new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);


    String outputString = output.toString();
    assertTrue("Expected error message for negative input not found.",
            outputString.contains("Invalid move. Try again: "));

    //ensure nothing was played to the palette (invalid input should not affect the game)
    assertFalse("Game should not have progressed with invalid input.",
            mockModel.palettePlayed);
  }

  @Test
  public void testPlayToPaletteWithLegalControllerAndModelInput() {
    //simulate valid input
    Readable input = new StringReader("1 2\n");  //legal input: pal 1, card at index 2
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelPlayToPalette mockModel =
            new Mocks.MockSoloRedGameModelPlayToPalette();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4), new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    assertFalse("Unexpected invalid input message found.",
            outputString.contains("Invalid move, try again: "));

    //check card was successfully played to the palette
    assertTrue("Card should have been played to the palette for legal input.",
            mockModel.palettePlayed);
  }


  @Test
  public void testConfirmInputsToPlayToPaletteModelMethods() {
    //valid input
    Readable input = new StringReader("1 2\n");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelPlayToPaletteIndex mockModel =
            new Mocks.MockSoloRedGameModelPlayToPaletteIndex();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4), new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    //verify playToPalette was called with correct inputs
    assertEquals("The player index passed to playToPalette is incorrect.",
            1, mockModel.loggedPlayerIndex);
    assertEquals("The card index passed to playToPalette is incorrect.",
            2, mockModel.loggedCardIndex);
  }

  @Test
  public void testPlayGameBehaviorWithStartGameExceptions() {
    Readable input = new StringReader("some input");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelGameException mockModel =
            new Mocks.MockSoloRedGameModelGameException();

    RedGameController controller = new SoloRedTextController(input, output);

    try {
      //will call startGame, which is overridden to throw an exception
      controller.playGame(mockModel, Arrays.asList(
                      new CardClass("R", 4), new CardClass("B", 1),
                      new CardClass("I", 3), new CardClass("V", 3),
                      new CardClass("R", 6), new CardClass("B", 5),
                      new CardClass("I", 2), new CardClass("V", 7)),
              false, 2, 2);

      //if no exception was thrown, this is an error
      fail("Expected an IllegalArgumentException to be thrown, but it was not.");
    } catch (IllegalArgumentException e) {
      //check if exception is caught and error message is logged
      String outputString = output.toString();
      assertTrue("Expected error message not found in output.",
              outputString.contains("Invalid game parameters\n"));
    }
  }

  //testConfirmInputsToPlayToCanvasModelMethods???
  @Test
  public void testInvalidCommandBehavior() {
    Readable input = new StringReader("invalidCommand\nq\n"); // invalid command, then quit
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelStartGame mockModel = new Mocks.MockSoloRedGameModelStartGame();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4), new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    //check output contains the expected message for an invalid command
    assertTrue("Expected invalid command message was not found in output.",
            outputString.contains("Invalid move, try again: "));

    //check that after the invalid command, the game still allowed further input (ex: quitting)
    assertTrue("Game did not quit as expected after 'q' command.",
            outputString.contains("Game quit!\n"));

    //check game started correctly, despite invalid commands during play
    assertTrue("Game did not start correctly.", mockModel.gameStarted);
  }

  @Test
  public void testPlayToPaletteExceptionsDoNotHaltProgram() {
    //simulated invalid play, then quit
    Readable input = new StringReader("invalidPlayToPalette\nq\n");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelPaletteAndGame mockModel =
            new Mocks.MockSoloRedGameModelPaletteAndGame();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4), new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    //check the output contains expected message for invalid play to palette
    assertTrue("Expected error message for playToPalette was not found.",
            outputString.contains("Invalid play to palette"));

    //verify game did not halt and continued to next command
    assertTrue("Game did not quit as expected after 'q' command.",
            outputString.contains("Game quit!\n"));

    //playToPalette was called and the exception did not halt the game
    assertTrue("playToPalette was not called.", mockModel.playToPaletteCalled);
    assertTrue("Game did not continue after exception.", mockModel.gameStarted);
  }

  @Test
  public void testSmallGameThatEndsWithMockModelWithOnlyValidLegalInput() {
    Readable input = new StringReader("1 1\nq\n"); //plays a card, then quit

    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelGameEndsNaturally mockModel =
            new Mocks.MockSoloRedGameModelGameEndsNaturally();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4), new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    //verify game started correctly
    assertTrue("Game should have started.", mockModel.gameStarted);

    //verify playToPalette was called correctly
    assertTrue("playToPalette should have been called.", mockModel.playToPaletteCalled);

    //game ended as expected
    assertTrue("Game should be over.", mockModel.isGameOver());

    //game quit as expected
    assertTrue("Game did not quit as expected.", outputString.contains("Game quit!"));
  }

  @Test
  public void testPlayToCanvasWithZeroAsInput() {
    //user tries to play a 0 (invalid input) followed by a quit command
    Readable input = new StringReader("0\nq\n");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelCanvasPlayed mockModel = new Mocks.MockSoloRedGameModelCanvasPlayed();

    RedGameController controller = new SoloRedTextController(input, output);

    controller.playGame(mockModel, Arrays.asList(
                    new CardClass("R", 4), new CardClass("B", 1),
                    new CardClass("I", 3), new CardClass("V", 3),
                    new CardClass("R", 6), new CardClass("B", 5),
                    new CardClass("I", 2), new CardClass("V", 7)),
            false, 2, 2);

    String outputString = output.toString();

    // check detected the invalid input (0) and gave an appropriate error message
    assertTrue("Expected invalid input message for 0 was not found.",
            outputString.contains("Invalid move, try again: "));

    //continued to allow user to quit, did not crash
    assertTrue("Expected the game to continue and allow quitting.",
            outputString.contains("Game quit!\n"));

    //game did not log any valid canvas move for the zero input
    assertFalse("Game should not log a move to the canvas with 0 as input.",
            mockModel.canvasPlayed);


  }

  @Test
  public void testPlayToPaletteWithNaturalNumbersBehavior() {
    //valid natural numbers (1, 2) followed by a quit command
    Readable input = new StringReader("1\n2\nq\n");
    Appendable output = new StringBuilder();

    Mocks.MockSoloRedGameModelPlayToPalette1 mockModel =
            new Mocks.MockSoloRedGameModelPlayToPalette1();

    RedGameController controller = new SoloRedTextController(input, output);

    List<CardClass> deck = Arrays.asList(
            new CardClass("R", 1),
            new CardClass("B", 2),
            new CardClass("V", 3),
            new CardClass("I", 4),
            new CardClass("R", 6), new CardClass("B", 5),
            new CardClass("I", 2), new CardClass("V", 7)
    );

    controller.playGame(mockModel, deck, false, 2, 2);

    assertTrue("Expected to play to palette for card 1.",
            mockModel.palettePlayed.contains(1));
    assertTrue("Expected to play to palette for card 2.",
            mockModel.palettePlayed.contains(2));

    //check output does not contain any error messages for invalid inputs
    String outputString = output.toString();
    assertFalse("Expected no invalid input messages.",
            outputString.contains("Invalid input, please try again"));

    //check if the game allows the user to quit after valid inputs
    assertTrue("Expected the game to allow quitting.", outputString.contains("Game quit"));
  }


  //    @Test
  //    public void testHandleQuit_ShouldRenderStateAndTransmitMessage() throws IOException {
  //      Readable readable = new StringReader("");
  //      StringBuilder appendable = new StringBuilder();
  //      SoloRedGameModel model = new SoloRedGameModel(4);
  //      model.isGameOver() = true; //set game over
  //
  //      SoloRedTextController controller = new SoloRedTextController(readable, appendable);
  //      controller.handleQuit(model);
  //
  //      //verify output for quitting
  //      assertEquals("Game quit!\nNumber of cards in deck: 4\n", appendable.toString());
  //    }

  //    @Test
  //    public void testTransmitShouldAppendMessage() throws IOException {
  //      Readable readable = new StringReader("");
  //      StringBuilder appendable = new StringBuilder();
  //
  //      SoloRedTextController controller = new SoloRedTextController(readable, appendable);
  //      controller.transmit("Hello, World!");
  //
  //      // Verify that the appendable received the message
  //      assertEquals("Hello, World!\n", appendable.toString());
  //    }


  /////////////////////////////////////////////////////////////////////////////////////////////////
  //constructor

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullRd() {
    SoloRedTextController contr = new SoloRedTextController(null, new StringBuilder());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullAp() {
    SoloRedTextController contr = new SoloRedTextController(new StringReader(""), null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorNullBoth() {
    SoloRedTextController contr = new SoloRedTextController(null, null);
  }

  //test null model
  @Test(expected = IllegalArgumentException.class)
  public void testNullModelThrowException() throws IOException {
    Readable readable = new StringReader("");
    Appendable appendable = new StringBuilder();

    SoloRedTextController controller = new SoloRedTextController(readable, appendable);

    //assert that passing null model throws an IllegalArgumentException
    controller.playGame(null, Arrays.asList(new CardClass("V", 2)), true,
            1, 1);

  }

  //test null deck
  @Test(expected = IllegalArgumentException.class)
  public void testNullDeckThrowException() throws IOException {
    Readable readable = new StringReader("");
    Appendable appendable = new StringBuilder();

    SoloRedTextController controller = new SoloRedTextController(readable, appendable);
    SoloRedGameModel model = new SoloRedGameModel();

    //assert that passing null deck throws an IllegalArgumentException
    controller.playGame(model, null, true, 1, 1);
  }

  //test invalid deck parameters
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidParameters() throws IOException {
    Readable readable = new StringReader("");
    StringBuilder appendable = new StringBuilder();

    SoloRedTextController controller = new SoloRedTextController(readable, appendable);
    SoloRedGameModel model = new SoloRedGameModel();

    //assert that passing null model throws an IllegalArgumentException
    controller.playGame(model, Arrays.asList(
            new CardClass("R", 4),
            new CardClass("B", 1),
            new CardClass("I", 3)), false, 1, 1);
  }

  @Test
  public void testPlayGameValidParametersShouldStartGame() throws IOException {
    Readable readable = new StringReader("");
    StringBuilder appendable = new StringBuilder();

    SoloRedTextController controller = new SoloRedTextController(readable, appendable);
    SoloRedGameModel model = new SoloRedGameModel();

    controller.playGame(model, Arrays.asList(new CardClass("R", 4), new CardClass("B", 1),
            new CardClass("I", 3)), false, 2, 1);

    //verify that the appendable contains expected output
    assertEquals("Game started!\nNumber of cards in deck: 3\n", appendable.toString());
  }

  //test invalid palette parameters
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidParametersPal() throws IOException {
    Readable readable = new StringReader("");
    StringBuilder appendable = new StringBuilder();

    SoloRedTextController controller = new SoloRedTextController(readable, appendable);
    SoloRedGameModel model = new SoloRedGameModel();

    //assert that passing invalid palette (1) throws an IllegalArgumentException
    controller.playGame(model, Arrays.asList(
            new CardClass("R", 4),
            new CardClass("B", 1),
            new CardClass("I", 3)), false, 1, 1);
  }

  //test invalid handSize parameters
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidParametersHand() throws IOException {
    Readable readable = new StringReader("");
    StringBuilder appendable = new StringBuilder();

    SoloRedTextController controller = new SoloRedTextController(readable, appendable);
    SoloRedGameModel model = new SoloRedGameModel();

    //assert that passing 0 handSize throws an IllegalArgumentException
    controller.playGame(model, Arrays.asList(
            new CardClass("R", 4),
            new CardClass("B", 1),
            new CardClass("I", 3)), false, 3, 0);
  }

  //  @Test
  //  public void testInvalidCommandInput() {
  //    StringReader input = new StringReader("invalidCommand\nq");
  //    StringBuilder output = new StringBuilder();
  //    SoloRedTextController controller = new SoloRedTextController(input, output);
  //
  //    SoloRedGameModel model = new SoloRedGameModel();
  //
  //    List<CardClass> deck = Arrays.asList(new CardClass("R", 4),
  //            new CardClass("B", 1),
  //            new CardClass("I", 3),
  //            new CardClass("R", 4),
  //            new CardClass("O", 3),
  //            new CardClass("V", 3));
  //
  //    controller.playGame(model, deck, false, 2, 5);
  //
  //    assertFalse(output.toString().contains("Invalid command. Try again."));
  //  }

  @Test(expected = IllegalArgumentException.class)
  public void testGameCannotStart() {
    StringReader input = new StringReader("q");
    StringBuilder output = new StringBuilder();
    SoloRedTextController controller = new SoloRedTextController(input, output);

    Mocks.MockSoloRedGameModelGameException failingModel =
            new Mocks.MockSoloRedGameModelGameException();

    List<CardClass> deck = Arrays.asList(new CardClass("R", 4),
            new CardClass("B", 1),
            new CardClass("I", 3));

    //simulate model that throws an IllegalArgumentException on start
    controller.playGame(failingModel, deck, false, 2, 5);
  }

  ////////more tests from hw 4


}
