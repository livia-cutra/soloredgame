package cs3500.solored;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cs3500.solored.controller.RedGameController;
import cs3500.solored.controller.SoloRedTextController;
import cs3500.solored.model.hw02.CardClass;
import cs3500.solored.model.hw02.RedGameModel;
import cs3500.solored.model.hw02.SoloRedGameModel;
import cs3500.solored.model.hw04.AdvancedSoloRedGameModel;

/**
 * runs a RedSoloGame interactively on the console.
 * deck has to be 35 cards and shuffled.
 */
public final class SoloRed {
  List<CardClass> deck;

  /**
   * initializes the input and output for the game, creates a controller.
   * @param args command-line arguments passed to the program (not used yet).
   */
  public static void main(String[] args) {
    //default number of palettes and hand size
    int palettes = 4;
    int handSize = 7;

    //ensure game type argument is provided
    if (args.length < 1) {
      throw new IllegalArgumentException("Game type not specified. Use 'basic' or 'advanced'.");
    }

    String gameType = args[0];

    //check if optional arguments for palettes and hand size are provided
    if (args.length >= 2) {
      try {
        palettes = Integer.parseInt(args[1]);
      } catch (NumberFormatException e) {
        //ignore invalid input
      }
    }

    if (args.length >= 3) {
      try {
        handSize = Integer.parseInt(args[2]);
      } catch (NumberFormatException e) {
        //ignore invalid input
      }
    }

    //ensure valid ranges for the parameters, so that it does not throw exception error?
    if (palettes < 2) {
      palettes = 2;
    }
    if (handSize < 1) {
      handSize = 1;
    }

    //create input and output for the game
    Readable input = new InputStreamReader(System.in);
    Appendable output = System.out;

    //initialize controller
    RedGameController controller = new SoloRedTextController(input, output);

    //initialize game model
    RedGameModel model;

    switch (gameType) {
      case "basic":
        model = new SoloRedGameModel();  // SoloRedGameModel
        break;

      case "advanced":
        model = new AdvancedSoloRedGameModel();  // AdvancedSoloRedGameModel
        break;

      default:
        throw new IllegalArgumentException("Invalid game type. Use 'basic' or 'advanced'.");
    }

    //full deck of 35 cards shuffled
    List<CardClass> deck = createAndShuffleDeck();

    controller.playGame(model, deck, true, palettes, handSize);
  }

  /**
   * creates and returns a shuffled deck containing all 35 cards.
   * @return a shuffled deck of 35 cards
   */
  private static List<CardClass> createAndShuffleDeck() {
    List<CardClass> deck = new ArrayList<>();

    String[] colors = {"R", "O", "B", "I", "V"};

    for (String color : colors) {
      for (int number = 1; number <= 7; number++) {
        deck.add(new CardClass(color, number));
      }
    }
    Collections.shuffle(deck);
    return deck;
  }
}

