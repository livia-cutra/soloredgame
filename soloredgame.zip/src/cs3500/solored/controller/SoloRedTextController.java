package cs3500.solored.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.RedGameModel;
import cs3500.solored.view.hw02.SoloRedGameTextView;

/**
 * a class that implements a controller interface.
 */
public class SoloRedTextController implements RedGameController {
  //abstracts input
  private final Scanner scanner;
  //abstracts output
  private final Appendable ap;
  //view
  private SoloRedGameTextView view;

  /**
   * constructor that takes in a readable and appendable.
   */
  public SoloRedTextController(Readable rd, Appendable ap) {
    if (rd == null || ap == null) {
      throw new IllegalArgumentException("readable or appendable cannot be null");
    }
    this.ap = ap;
    this.scanner = new Scanner(rd);
  }

  /**
   * method to play the game via controller.
   *
   * @throw IllegalArgumentException if the provided model is null
   * @throw IllegalStateException if controller is unable to receive input or transmit output
   * @throw IllegalArgumentException if the game cannot be started
   */
  @Override
  public <C extends Card> void playGame(RedGameModel<C> model, List<C> deck, boolean shuffle,
                                        int numPalettes, int handSize) {


    //check for null model
    if (model == null) {
      throw new IllegalArgumentException("model cannot be null");
    }
    //check for deck != null
    if (deck == null) {
      throw new IllegalArgumentException("deck is null");
    }

    view = new SoloRedGameTextView(model, ap); //connecting controller to view

    //checks if game cannot be started
    model.startGame(deck, shuffle, numPalettes, handSize);
    //start the game
    controllerStartGame(model, deck, shuffle, numPalettes, handSize);

    //run the game loop
    runGameLoop(model, handSize);
  }

  /**
   * helper method that starts the game.
   */
  private <C extends Card> void controllerStartGame(RedGameModel<C> model,
                                                    List<C> deck, boolean shuffle, int numPalettes,
                                                    int handSize) {

    try {
      //initialize state transmission
      //check if the game isnt over, which in turn checks if the game has started
      if (!model.isGameOver()) {
        view.render();  //render game state
        transmit("Number of cards in deck: " + model.numOfCardsInDeck());
      } else {
        throw new IllegalStateException("Game did not start correctly.");
      }
    } catch (IOException e) {
      throw new IllegalStateException("Unable to transmit output.", e);
    }
  }

  /**
   * helper method that handles the main game loop.
   */
  private <C extends Card> void runGameLoop(RedGameModel<C> model, int handSize) {
    try {
      while (!model.isGameOver()) {
        String command;
        // read the next valid command from the user
        try {
          command = readNextValidCommand(scanner);
        } catch (IOException e) {
          throw new IllegalStateException("unable to receive input.", e);
        }
        //handling if it is quit
        if (command.equals("q")) {
          transmit("Game quit!");
          transmit("State of game when quit:");
          view.render();  //render current game state
          transmit("Number of cards in deck: " + model.numOfCardsInDeck());
          //handleQuit(model);
          return;
        }

        //handling if it is a canvas or palette command
        handleCommand(command, scanner, model, handSize);

        //draw cards until the hand is full or the deck is empty
        model.drawForHand();

        //render updated game state
        renderGameState(model);
      }
      //handling if game end
      handleGameEnd(model);

    } catch (IOException e) {
      throw new IllegalStateException("Unable to transmit output.", e);
    }
  }

  /**
   * helper method that handles commands inputted by the user.
   *
   * @throws IOException if cannot receive input or read output.
   */
  private <C extends Card> void handleCommand(String command, Scanner scanner,
                                              RedGameModel<C> model, int handSize)
          throws IOException {
    if (command.equals("palette")) {
      int paletteIndex = readNextInt(scanner, model, handSize) - 1;  //convert to 0-based index
      int cardIndex = readNextInt(scanner, model, handSize) - 1;     //convert to 0-based index
      try {
        model.playToPalette(paletteIndex, cardIndex);
        // after the move, check if the game is over
        if (model.isGameOver()) {
          //if the game is over, handle the end-game logic
          transmit("Game over!");
          transmit("State of game when quit:");
          view.render();  //render current game state
          transmit("Number of cards in deck: " + model.numOfCardsInDeck());
          return;
        }
      } catch (IllegalArgumentException e) {
        transmit("Invalid move. Try again: " + e.getMessage());
      }
    } else if (command.equals("canvas")) {
      int cardIndex = readNextInt(scanner, model, handSize) - 1;  //convert to 0-based index
      try {
        model.playToCanvas(cardIndex);
      } catch (IllegalArgumentException e) {
        transmit("Invalid move. Try again: " + e.getMessage());
      }
    }

  }

  /**
   * helper method that reveals the current game state.
   *
   * @throws IOException if cannot receive input or read output.
   */
  private <C extends Card> void renderGameState(RedGameModel<C> model) throws IOException {
    //render the updated game state and number of cards in deck
    view.render();
  }

  /**
   * helper method that handles what is rendered when game ends (win or lose).
   *
   * @throws IOException if cannot receive input or read output.
   */
  private <C extends Card> void handleGameEnd(RedGameModel<C> model) throws IOException {
    //game is over: check if it's won or lost
    if (model.isGameWon()) {
      transmit("Game won!");
    } else {
      transmit("Game lost!");
    }
    //final statement
    renderGameState(model);
  }

  /**
   * a helper method to read input from the user and decide what to return.
   */
  private String readNextValidCommand(Scanner scanner) throws IOException {
    while (scanner.hasNext()) { //hasNextLine()?
      String input = scanner.next(); //hasNextLine()?

      //check for 'q' or 'Q' to quit
      if (input.equals("q") || input.equals("Q")) {
        return "q";
      }

      //check for valid commands: "palette", "canvas"
      else if (input.equals("palette") || input.equals("canvas")) {
        return input;

      } else {
        //if it's an invalid command, prompt the user to try again
        try {
          this.ap.append("Invalid command. Try again.\n");
        } catch (IOException e) {
          throw new IllegalStateException("Failed to transmit output.", e);
        }
      }
    }
    throw new IllegalStateException("No more input available.");
  }

  /**
   * a helper method that reads the next integer and ensures it is a valid integer.
   */
  private int readNextInt(Scanner scanner, RedGameModel<?> model, int handSize) {
    try {
      while (true) {
        //checks if next is an integer
        if (scanner.hasNextInt()) {
          int nextInt = scanner.nextInt(); //new
          if (nextInt > 0 && nextInt <= handSize) { //new
            return nextInt; //returns valid integer //new
          }
          //return scanner.nextInt(); //returns valid integer
        } else {
          String nextInput = scanner.next();
          if (nextInput.equalsIgnoreCase("Q")) {
            transmit("Game quit!");
            transmit("State of game when quit:");
            view.render();  //render current game state
            transmit("Number of cards in deck: " + model.numOfCardsInDeck());
          }
        }
      }
    } catch (IOException e) {
      throw new IllegalStateException("Unable to transmit output.", e);
    }
  }

  /**
   * helper that transmits messages as it appends them to the ouput.
   */
  private void transmit(String message) {
    try {
      ap.append(message + "\n");
    } catch (IOException ex) {
      throw new IllegalStateException("Append fail.");
    }
  }

}

