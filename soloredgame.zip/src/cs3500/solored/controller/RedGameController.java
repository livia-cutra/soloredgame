package cs3500.solored.controller;

import java.util.List;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.RedGameModel;

/**
 * interface that represents the controller for the redsologame.
 */
public interface RedGameController {

  /**
   * method to play the game.
   * @throw IllegalArgumentException if the provided model is null
   * @throw IllegalStateException if controller is unable to receive input or transmit output
   * @throw IllegalArgumentException if the game cannot be started
   */
  public <C extends Card> void playGame(RedGameModel<C> model, List<C> deck, boolean shuffle,
                                        int numPalettes, int handSize);


}
