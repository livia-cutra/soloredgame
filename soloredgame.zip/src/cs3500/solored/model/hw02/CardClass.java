package cs3500.solored.model.hw02;

import java.util.Objects;

import cs3500.solored.model.hw02.Card;

/**
 * class that represents a card in the game.
 */
public class CardClass implements Comparable<CardClass>, Card {

  public String correctCardOrder;
  public String color;
  public int num;

  /**
   * constructor for CardClass.
   */
  public CardClass(String color, int num) {
    this.color = color;
    this.num = num;
    this.correctCardOrder = color.substring(0, 1) + num; // Assuming you want to format this too

    if (num < 1 || num > 7) {
      throw new IllegalArgumentException("numbers must be 1-7");
    }
    if (color == null
            ||
            (!color.equals("R")
            &&
            !color.equals("O")
            &&
            !color.equals("B")
            &&
            !color.equals("I")
            &&
            !color.equals("V"))) {
      throw new IllegalArgumentException("colors must be either R, O, B, I, V");
    }
  }

  /**
   * format cards correctly based off of color and number.
   *
   * @param color is the color of the card.
   * @param num   is the number associated with the card
   *              between the parameters 1-7.
   */
  public void cardFormat(String color, int num) {

    correctCardOrder = color.substring(0, 1) + num;
  }

  @Override
  public String toString() {
    return color + num;
  }

  /**
   * get card number.
   * @return number of the card
   */
  public int getNumber() {
    return this.num;
  }

  /**
   * get card color.
   *
   * @return color of card as String
   */
  public String getColor() {
    return this.color;
  }

  /**
   * compares two cards to se eif they are equal.
   *
   * @param o object to compare to
   * @return true if cards are the same, false if they are not
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof CardClass)) {
      return false;
    }
    CardClass card = (CardClass) o;
    return num == card.num && color.equals(card.color);
  }

  /**
   * creates hashcode for specific card.
   *
   * @return the hash code.
   */
  @Override
  public int hashCode() {
    return Objects.hash(color, num);
  }

  /**
   * compares two card classes.
   * @param other CardClass to be compared.
   * @return the integer that is larger by color or number
   */
  public int compareTo(CardClass other) {
    //System.out.println("Comparing " + this + " with " + other);
    //first, compare by number
    if (this.num != other.num) {
      return Integer.compare(this.num, other.num);

    }

    //if numbers are equal, compare by color based on the rainbow order: R > O > B > I > V
    return compareColors(this.color, other.color);
  }


  /**
   * compares two colors based on rainbow order.
   * @param color1 first color to compare.
   * @param color2 second color to compare.
   */
  private int compareColors(String color1, String color2) {
    String[] rainbowOrder = {"V", "I", "B", "O", "R"};
    int index1 = -1;
    int index2 = -1;

    for (int i = 0; i < rainbowOrder.length; i++) {
      if (rainbowOrder[i].equals(color1)) {
        index1 = i;
      }
      if (rainbowOrder[i].equals(color2)) {
        index2 = i;
      }
    }

    return Integer.compare(index1, index2);
  }
}


