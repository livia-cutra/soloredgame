package cs3500.solored.model.hw02;

import java.util.Random;

import cs3500.solored.model.hw04.AbstractSoloRedGameModel;

/**
 * represents the model for a single-player Red card game.
 *
 * <p>This model handles the game's state, rules, and player actions, such as starting the game,
 * playing cards, and determining the winner. It manages palettes and hands for each player
 * according to the game's logic.</p>
 */
public class SoloRedGameModel extends AbstractSoloRedGameModel {

  /**
   * completely random constructor.
   */
  public SoloRedGameModel() {
    super(new Random());
  }

  /**
   * constructor with random seeded parameter.
   */
  public SoloRedGameModel(Random random) {
    super(random);
  }

}

