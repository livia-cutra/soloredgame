package cs3500.solored.model.hw04;

import cs3500.solored.model.hw02.RedGameModel;
import cs3500.solored.model.hw02.SoloRedGameModel;

/**
 * A factory class for creating instances of RedGameModel. This class uses the
 * Factory Design Pattern to instantiate either a SoloRedGameModel or
 * AdvancedSoloRedGameModel based on the specified GameType.
 */
public class RedGameCreator {

  /**
   * enum representing the two types of games: BASIC and ADVANCED.
   */
  public enum GameType {
    BASIC, ADVANCED
  }

  /**
   * Factory method to create a RedGameModel based on the given GameType.
   *
   * @param type the type of game to create (BASIC or ADVANCED)
   * @return an instance of RedGameModel, either SoloRedGameModel or AdvancedSoloRedGameModel
   */
  public static RedGameModel createGame(GameType type) {
    switch (type) {
      case BASIC:
        return new SoloRedGameModel();
      case ADVANCED:
        return new AdvancedSoloRedGameModel();
      default:
        throw new IllegalArgumentException("Invalid game type");
    }
  }
}

