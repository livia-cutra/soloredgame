package cs3500.solored.model.hw04;


import java.util.Random;

import cs3500.solored.model.hw02.CardClass;

/**
 * represents an advanced version of the SoloRedGameModel. This class extends the
 * AbstractSoloRedGameModel class and introduces additional functionality, such as
 * modifying the number of cards drawn after a player plays a card to the palette.
 *
 * <p>The game enforces the following rules:
 * <ul>
 *   <li>When a card is played to the palette, the player automatically draws a card or cards
 *   based on the cardsToDraw value.</li>
 *   <li>The cardsToDraw value is reset to 1 after the drawing phase is completed.</li>
 * </ul>
 */
public class AdvancedSoloRedGameModel extends AbstractSoloRedGameModel {
  private int cardsToDraw = 1; // Tracks how many cards can be drawn after playing to palette

  /**
   * completely random constructor.
   */
  public AdvancedSoloRedGameModel() {
    super(new Random());
  }

  /**
   * constructor with random seeded parameter.
   */
  public AdvancedSoloRedGameModel(Random random) {
    super(random);
  }

  @Override
  public void playToCanvas(int cardIdxInHand) {
    super.playToCanvas(cardIdxInHand);
    CardClass cardPlayed = canvas; //canvas holds the last card played to the canvas
    int winningPaletteSize = palettes.get(winningPaletteIndex()).size();

    //check if the card played to canvas allows drawing an extra card
    if (cardPlayed.getNumber() > winningPaletteSize) {
      cardsToDraw = 2;
    } else {
      cardsToDraw = 1;
    }
  }

  @Override
  public void playToPalette(int paletteIdx, int cardIdxInHand) {
    super.playToPalette(paletteIdx, cardIdxInHand);
    drawForHand();
  }

  @Override
  public void drawForHand() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }

    // draw the appropriate number of cards based on cardsToDraw
    for (int i = 0; i < cardsToDraw && hand.size() < handSize && !deck.isEmpty(); i++) {
      hand.add(deck.remove(0));
    }

    //reset cardsToDraw to 1 after drawing
    cardsToDraw = 1;
  }
}
