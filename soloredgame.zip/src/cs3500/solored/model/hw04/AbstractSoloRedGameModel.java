package cs3500.solored.model.hw04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import cs3500.solored.model.hw02.CardClass;
import cs3500.solored.model.hw02.RedGameModel;

/**
 * an abstract class that represents the core functionality of the SoloRed game model.
 * this class implements the RedGameModel interface and provides
 * methods for initializing the deck, starting the game, and managing gameplay.
 *
 * <p>this class also provides logic for comparing palettes based on various rules dictated by
 * color.</p>
 *
 */
public abstract class AbstractSoloRedGameModel implements RedGameModel<CardClass> {
  protected List<CardClass> deck;
  protected List<List<CardClass>> palettes;
  protected List<CardClass> hand;
  protected CardClass canvas;
  protected boolean gameStarted;
  protected int handSize;
  protected Random random;
  protected boolean gameOver;

  /**
   * completely random constructor.
   */
  public AbstractSoloRedGameModel() {
    this(new Random());
    this.deck = new ArrayList<>();
    initializeDeck();
    this.palettes = new ArrayList<>();
    this.hand = new ArrayList<>();
    //this.canvas = new CardClass("R", 1);
    this.gameStarted = false;
    this.gameOver = false;
  }

  /**
   * constructor with random seeded parameter.
   */
  public AbstractSoloRedGameModel(Random random) {
    if (random == null) {
      throw new IllegalArgumentException("Random object cannot be null");
    }
    this.random = random;
    this.deck = new ArrayList<>();
    initializeDeck();
    this.palettes = new ArrayList<>();
    this.hand = new ArrayList<>();
    //this.canvas = new CardClass("R", 1);
    this.gameStarted = false;
  }

  /**
   * method to initialize the deck.
   */
  private void initializeDeck() {
    //populate the deck with cards
    for (int cardValue = 1; cardValue <= 7; cardValue++) {
      deck.add(new CardClass("R", cardValue)); //red cards
      deck.add(new CardClass("B", cardValue)); //blue cards
      deck.add(new CardClass("I", cardValue)); //indigo cards
      deck.add(new CardClass("V", cardValue)); //violet cards
      deck.add(new CardClass("O", cardValue)); //orange cards
    }

  }

  @Override
  public void startGame(List<CardClass> deck, boolean shuffle, int numPalettes, int handSize) {


    if (deck == null || deck.isEmpty()) {
      throw new IllegalArgumentException("Invalid game parameters");
    }

    if (deck.size() < numPalettes + handSize) {
      throw new IllegalArgumentException("Not enough cards to start the game");
    }
    if (numPalettes < 2 || handSize <= 0) {
      throw new IllegalArgumentException("Invalid number of palettes or hand size");
    }

    // Check for duplicate cards
    Set<CardClass> uniqueCards = new HashSet<>(deck);
    if (uniqueCards.size() != deck.size()) {
      throw new IllegalArgumentException("Deck contains duplicate cards");
    }

    this.deck = new ArrayList<>(deck);
    if (shuffle) {
      Collections.shuffle(this.deck, this.random);
    }

    this.palettes = new ArrayList<>();
    for (int i = 0; i < numPalettes; i++) {
      List<CardClass> palette = new ArrayList<>();
      palette.add(this.deck.remove(0));
      this.palettes.add(palette);
    }

    this.hand = new ArrayList<>();
    for (int i = 0; i < handSize; i++) {
      this.hand.add(this.deck.remove(0));
    }

    this.handSize = handSize;
    this.gameStarted = true;
    this.canvas = new CardClass("R", 1); //start with Red 1 on canvas
  }

  @Override
  public void playToPalette(int paletteIdx, int cardIdxInHand) {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    if (paletteIdx < 0 || paletteIdx >= palettes.size()) {
      throw new IllegalArgumentException("Invalid palette index");
    }
    if (cardIdxInHand < 0 || cardIdxInHand >= hand.size()) {
      throw new IllegalArgumentException("Invalid card index in hand");
    }

    List<CardClass> targetPalette = palettes.get(paletteIdx);
    CardClass cardToPlay = hand.get(cardIdxInHand);
    CardClass topCard = targetPalette.get(targetPalette.size() - 1);

    //do have to check if you are playing to a winning palette which you cannot do
    // Get the index of the current winning palette
    int winningPaletteIdx = winningPaletteIndex();

    // If the paletteIdx refers to the winning palette, throw IllegalStateException
    if (paletteIdx == winningPaletteIdx) {
      throw new IllegalStateException("Cannot play to the winning palette");
    }

    //unnecessary?
    //      if (canvas.getColor().equals("R") && cardToPlay.compareTo(topCard) < 0) {
    //        throw new IllegalStateException("Cannot play a card of lower value under Red rules");
    //      }

    hand.remove(cardIdxInHand);
    targetPalette.add(cardToPlay);

    //check if the player has played to a losing palette
    if (!isPlayableToPalette(paletteIdx)) {
      //the player played to a losing palette, and the game should end in a loss
      gameOver = true;
      isGameOver(); //idk if i should do this too?
    }

  }


  //track if canvas was played to
  private boolean playedToCanvasThisTurn = false;

  @Override
  public void playToCanvas(int cardIdxInHand) {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    if (cardIdxInHand < 0 || cardIdxInHand >= hand.size()) {
      throw new IllegalArgumentException("Invalid card index in hand");
    }

    if (hand.size() == 1) {
      throw new IllegalStateException("Cannot play with only one card in hand");
    }

    if (playedToCanvasThisTurn) {
      throw new IllegalStateException("Cannot play to the canvas twice in a row");
    }
    CardClass cardToPlay = hand.remove(cardIdxInHand);
    canvas = cardToPlay;
    playedToCanvasThisTurn = true;  // sets flag to true after playing to the canvas
  }

  @Override
  public void drawForHand() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    while (hand.size() < handSize && !deck.isEmpty()) {
      hand.add(deck.remove(0));
    }
  }

  @Override
  public int numOfCardsInDeck() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    return deck.size();
  }

  @Override
  public int numPalettes() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    return palettes.size();
  }

  @Override
  public List<CardClass> getHand() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    return this.hand;
  }

  @Override
  public List<CardClass> getPalette(int paletteNum) {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    if (paletteNum < 0 || paletteNum >= palettes.size()) {
      throw new IllegalArgumentException("Invalid palette number");
    }
    return new ArrayList<>(palettes.get(paletteNum));
  }

  @Override
  public CardClass getCanvas() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    return canvas;
  }

  @Override
  public List<CardClass> getAllCards() {
    List<CardClass> allCards = new ArrayList<>();
    String[] colors = {"R", "O", "B", "I", "V"};
    for (String color : colors) {
      for (int i = 1; i <= 7; i++) {
        allCards.add(new CardClass(color, i));
      }
    }
    return allCards;
  }

  @Override
  public int winningPaletteIndex() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    int winningIndex = 0;
    for (int i = 1; i < palettes.size(); i++) {
      if (arePalettesComparable(palettes.get(i), palettes.get(winningIndex))) {
        winningIndex = i;
      }
    }
    return winningIndex;
  }

  protected boolean arePalettesComparable(List<CardClass> firstPalette,
                                          List<CardClass> secondPalette) {
    switch (canvas.getColor()) {
      case "R":
        return applyRedComparisonRule(firstPalette, secondPalette);
      case "O":
        return applyOrangeComparisonRule(firstPalette, secondPalette);
      case "B":
        return applyBlueComparisonRule(firstPalette, secondPalette);
      case "I":
        return applyIndigoComparisonRule(firstPalette, secondPalette);
      case "V":
        return applyVioletComparisonRule(firstPalette, secondPalette);
      default:
        throw new IllegalStateException("Invalid canvas color");
    }
  }

  protected boolean applyRedComparisonRule(List<CardClass> firstPalette,
                                           List<CardClass> secondPalette) {
    CardClass highestCardInFirst = Collections.max(firstPalette);
    CardClass highestCardInSecond = Collections.max(secondPalette);
    return highestCardInFirst.compareTo(highestCardInSecond) > 0;
  }

  protected boolean applyOrangeComparisonRule(List<CardClass> firstPalette,
                                              List<CardClass> secondPalette) {
    int firstP = getMostFrequentNumberCount(firstPalette);
    int secondP = getMostFrequentNumberCount(secondPalette);

    if (firstP == secondP) {
      //if tied, use red rule to break the tie
      return applyRedComparisonRule(firstPalette, secondPalette);
    }
    return firstP > secondP;
  }

  protected boolean applyBlueComparisonRule(List<CardClass> firstPalette,
                                            List<CardClass> secondPalette) {
    int firstP = getDistinctColorCount(firstPalette);
    int secondP = getDistinctColorCount(secondPalette);

    if (firstP == secondP) {
      //if tied, use red rule to break the tie
      return applyRedComparisonRule(firstPalette, secondPalette);
    }
    return firstP > secondP;
  }

  protected boolean applyIndigoComparisonRule(List<CardClass> firstPalette,
                                              List<CardClass> secondPalette) {
    int firstScore = computeIndigoScore(firstPalette);
    int secondScore = computeIndigoScore(secondPalette);

    if (firstScore == secondScore) {
      //if tied, use red rule to break the tie
      return applyRedComparisonRule(firstPalette, secondPalette);
    }
    return firstScore > secondScore;
  }

  protected int computeIndigoScore(List<CardClass> palette) {
    Set<Integer> uniqueNumbersSet = new HashSet<>();
    int currentConsecutive = 0;
    int maxConsecutive = 0;

    for (CardClass card : palette) {
      int number = card.getNumber();
      if (uniqueNumbersSet.contains(number - 1)) {
        currentConsecutive++;
      } else {
        currentConsecutive = 1;
      }
      uniqueNumbersSet.add(number);
      maxConsecutive = Math.max(maxConsecutive, currentConsecutive);
    }

    return maxConsecutive;
  }

  protected boolean applyVioletComparisonRule(List<CardClass> firstPalette,
                                              List<CardClass> secondPalette) {
    int firstCount = countCardsBelowFour(firstPalette);
    int secondCount = countCardsBelowFour(secondPalette);

    if (firstCount == secondCount) {
      //use the highest cards to determine the winner
      return applyRedComparisonRule(firstPalette, secondPalette);
    }
    return firstCount > secondCount;
  }

  protected int countCardsBelowFour(List<CardClass> palette) {
    int count = 0;
    for (CardClass card : palette) {
      if (card.getNumber() < 4) {
        count++;
      }
    }
    return count;
  }

  protected int getDistinctColorCount(List<CardClass> palette) {
    Set<String> distinctColorsSet = new HashSet<>();
    for (CardClass card : palette) {
      distinctColorsSet.add(card.getColor());
    }
    return distinctColorsSet.size();
  }

  protected int getMostFrequentNumberCount(List<CardClass> palette) {
    Map<Integer, Integer> numberFrequencyMap = new HashMap<>();
    for (CardClass card : palette) {
      int number = card.getNumber();
      numberFrequencyMap.put(number, numberFrequencyMap.getOrDefault(number, 0) + 1);
    }

    return numberFrequencyMap.values().stream().max(Integer::compare).orElse(0);
  }

  /**
   * Return the deck.
   * Modifying this card has no effect on the game.
   *
   * @return the top card of the canvas
   * @throws IllegalStateException if the game has not started or the game is over
   */
  protected List<CardClass> retrieveDeck() {
    // checks if game has not started
    if (!gameStarted) {
      throw new IllegalStateException("game has not started yet");
    }

    return this.deck;
  }

  protected boolean isValidMovePossible() {
    //check for any playable moves to all palettes, including the winning one
    int indexOfWinningPalette = winningPaletteIndex();
    for (int i = 0; i < palettes.size(); i++) {
      if (isPlayableToPalette(i) && i != indexOfWinningPalette) {
        return true; //a valid move exists
      }
    }
    return false; //no valid moves are possible
  }

  protected boolean isPlayableToPalette(int paletteIndex) {
    List<CardClass> selectedPalette = palettes.get(paletteIndex);
    CardClass topCardInPalette = selectedPalette.get(selectedPalette.size() - 1);
    for (CardClass card : hand) {
      if (card.compareTo(topCardInPalette) > 0) {
        return true;
      }
    }
    return false;
  }

  @Override
  public boolean isGameOver() {
    if (!this.gameStarted) {
      throw new IllegalStateException("Game has not started");
    }

    if (gameOver) {
      return true;
    }

    // win condition: hand and deck are both empty
    if (hand.isEmpty() && deck.isEmpty()) {
      gameOver = true;
      return true; //the game is over, and the player has won
    }

    // loss condition: check if the player played to a losing palette
    if (!isValidMovePossible()) {
      gameOver = true;
      return true; //the game is over, and the player has lost
    }

    //game is not over yet
    gameOver = false;
    return false;
  }



  @Override
  public boolean isGameWon() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not started");
    }
    return isGameOver() && winningPaletteIndex() == 0;
  }
}
