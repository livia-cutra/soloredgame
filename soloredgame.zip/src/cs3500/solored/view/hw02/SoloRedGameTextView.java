package cs3500.solored.view.hw02;

import java.io.IOException;
import java.util.List;

import cs3500.solored.model.hw02.Card;
import cs3500.solored.model.hw02.RedGameModel;

/**
 * A text-based view for the Solo Red Game.
 */
public class SoloRedGameTextView<C extends Card> implements RedGameView {
  private final RedGameModel<?> model;
  //private final Readable in;
  private final Appendable ap;


  /**
   * Constructs a SoloRedGameTextView with the specified model and appendable.
   *
   * @param model the RedGameModel that provides the game state
   * @param ap    the Appendable
   */
  public SoloRedGameTextView(RedGameModel<?> model, Appendable ap) {
    if (ap == null) {
      throw new IllegalArgumentException();
    }
    this.model = model;
    this.ap = ap;

  }

  /**
   * Constructs a SoloRedGameTextView with the specified model.
   *
   * @param model the RedGameModel that provides the game state
   */
  public SoloRedGameTextView(RedGameModel<?> model) {
    this.model = model;
    this.ap = new StringBuilder(); //idk
    if (ap == null) {
      throw new IllegalArgumentException();
    }
  }

  /**
   * Returns a string representation of the current game state.
   *
   * @return a string displaying the canvas, palettes, and hand
   */
  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();

    //display the canvas
    sb.append("Canvas: ");
    if (model.getCanvas() != null) {
      sb.append(model.getCanvas().toString().charAt(0));
    }
    sb.append("\n");

    //display each palette
    int winningPaletteIndex = model.winningPaletteIndex();
    int numberOfPalettes = model.numPalettes();
    for (int i = 0; i < numberOfPalettes; i++) {
      //check if this is the winning palette
      if (i == winningPaletteIndex) {
        sb.append("> "); //append ">" for the winning palette
      }
      sb.append("P").append(i + 1).append(": ");
      // get the specific palette by index
      List<?> palette = model.getPalette(i);
      for (int j = 0; j < palette.size(); j++) {
        sb.append(palette.get(j).toString());
        if (j < palette.size() - 1) {
          sb.append(" ");
        }
      }
      sb.append("\n");
    }

    //display the hand
    sb.append("Hand: ");
    if (model.getHand().isEmpty()) {
      sb.append("\n");
    } else {
      //flatten the hand display to avoid nested lists
      sb.append(cardsToString(model.getHand())).append("\n");
    }
    //    sb.append("\n");
    //finalize the output string
    return sb.toString().trim();
  }

  /**
   * Renders a model in some manner (e.g. as text, or as graphics, etc.).
   *
   * @throws IOException if the rendering fails for some reason
   */
  public void render() throws IOException {
    //check if game started
    // if (model.isGameOver()) {
    //  throw new IllegalStateException("Cannot render: Game has not started");
    //    }
    // render canvas cards
    ap.append("Canvas: " + model.getCanvas().toString().charAt(0) + "\n");

    // render palettes generically
    renderPalettes();

    //render hand
    ap.append("Hand: ");
    if (model.getHand().isEmpty()) {
      //ap.append("\n"); "render output should not end in newline"
    } else {
      ap.append(cardsToString(model.getHand())).append("\n");
    }
  }


  private void renderPalettes() throws IOException {
    int winningPaletteIndex = model.winningPaletteIndex();
    for (int i = 0; i < model.numPalettes(); i++) {
      //check if this is the winning palette
      if (i == winningPaletteIndex) {
        ap.append("> "); //append ">" for the winning palette
      }
      ap.append("P").append(String.valueOf(i + 1)).append(": ")
              .append(cardsToString(model.getPalette(i)));

      ap.append("\n"); //newline for the next palette
    }
  }


  // helper method to convert list of cards to string
  private <C extends Card> String cardsToString(List<C> cards) {
    StringBuilder sb = new StringBuilder();
    for (C card : cards) {
      sb.append(card.toString()).append(" "); // ensure a consistent format
    }
    //remove the trailing space if any cards were added
    if (sb.length() > 0) {
      sb.setLength(sb.length() - 1); //remove the last space
    }
    return sb.toString();
  }
}
